const usuario = {
    nome: 'Clark Kent',
    id: 12345,
    idade: 38,
    profissao: 'Repórter',
    email: 'clark@planetadiario.com'
}
console.log(usuario);

console.log(`Nome: ${usuario.nome}`);
console.log(`Id: ${usuario.id}`);
console.log(`Email: ${usuario.email}`);