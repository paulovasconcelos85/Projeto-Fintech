const calcularValores = (valor1, valor2) => {
  console.log(`Resultado da Soma: ${valor1 + valor2}`);
  console.log(`Resultado da Multiplicação: ${valor1 * valor2}`);
}
calcularValores(20,10);